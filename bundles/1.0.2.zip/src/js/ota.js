/**
 * ota.js — self-hosted OTA updates via @capgo/capacitor-updater (manual mode, autoUpdate:false).
 *
 * Flow (native app only; the web/PWA build skips all of this):
 *   1. APP_CONFIG.otaManifestUrl is fetched: { version, url, sha256, min_native_version }.
 *   2. If min_native_version > the installed app versionName, show the "new app version needed"
 *      banner and stop — an OTA bundle cannot be applied on top of a too-old native shell.
 *   3. Otherwise, if manifest.version > the currently running bundle version, download the bundle
 *      (the plugin verifies the sha256 via its `checksum` option) and `set()` it so it applies on
 *      the next launch.
 *   4. notifyAppReady() is called once the UI has finished initializing (app.js hooks into
 *      ShiftOTA.onAppReady()). If a freshly applied bundle never calls it within the plugin's
 *      appReadyTimeout, the plugin rolls back to the previous bundle automatically.
 *
 * Every failure is logged to the console only — an OTA problem must never break the app.
 */
(function (global) {
  'use strict';

  const MIN_NATIVE_BANNER = 'A new app version is needed, ask Ahmed for the latest install.';
  let notifiedReady = false;

  function cap() { return global.Capacitor; }

  function isNative() {
    const C = cap();
    return !!(C && C.isNativePlatform && C.isNativePlatform());
  }

  function updaterPlugin() {
    if (!isNative()) return null;
    const C = cap();
    return (C.Plugins && C.Plugins.CapacitorUpdater) || (C.registerPlugin ? C.registerPlugin('CapacitorUpdater') : null);
  }

  function appPlugin() {
    if (!isNative()) return null;
    const C = cap();
    return (C.Plugins && C.Plugins.App) || (C.registerPlugin ? C.registerPlugin('App') : null);
  }

  /* Semver-ish compare. Splits each side on '-', then on '.'; numeric parts compare numerically.
   * Missing parts count as 0, so 1.0 < 1.0.1. If the numeric cores tie, a version carrying a
   * suffix ("1.0.1-ota1") counts as NEWER than the bare number ("1.0.1") — that is what we want,
   * because OTA bundles are always published with a -ota… suffix on top of a base version.
   * Returns -1, 0 or 1. */
  function compareVersions(a, b) {
    if (a === b) return 0;
    if (!a) return -1;
    if (!b) return 1;
    const split = (v) => {
      const dash = String(v).indexOf('-');
      const core = dash === -1 ? String(v) : String(v).slice(0, dash);
      const suffix = dash === -1 ? '' : String(v).slice(dash + 1);
      return { core: core.split('.'), suffix };
    };
    const pa = split(a);
    const pb = split(b);
    const len = Math.max(pa.core.length, pb.core.length);
    for (let i = 0; i < len; i++) {
      const x = Number.parseInt(pa.core[i], 10);
      const y = Number.parseInt(pb.core[i], 10);
      const nx = Number.isNaN(x) ? 0 : x;
      const ny = Number.isNaN(y) ? 0 : y;
      if (nx !== ny) return nx < ny ? -1 : 1;
    }
    if (pa.suffix === pb.suffix) return 0;
    if (!pa.suffix) return -1; // bare number loses to a -ota suffixed build of the same core
    if (!pb.suffix) return 1;
    return pa.suffix < pb.suffix ? -1 : 1;
  }

  /** Unhide the fixed banner and put `text` in it. */
  function showBanner(text) {
    try {
      const el = global.document && global.document.getElementById('otaBanner');
      if (!el) return;
      el.textContent = text;
      el.hidden = false;
    } catch (err) { /* banner is best-effort */ }
  }

  async function fetchManifest() {
    const cfg = global.APP_CONFIG || {};
    const url = cfg.otaManifestUrl;
    if (!url) return null;
    // Plain same-origin-independent GET; GitHub Pages may serve the manifest from its edge cache
    // for up to ~10 minutes (its max-age), which is fine for a manifest checked at every launch.
    const res = await fetch(url);
    if (!res.ok) throw new Error('manifest HTTP ' + res.status);
    return res.json();
  }

  async function nativeVersion() {
    const app = appPlugin();
    if (!app || !app.getInfo) return null;
    const info = await app.getInfo();
    return info && info.version ? info.version : null;
  }

  /** Version of the web bundle the WebView is running right now (an OTA id, or the builtin one). */
  async function currentBundleVersion(updater) {
    try {
      if (updater.getCurrentBundle) {
        const cur = await updater.getCurrentBundle();
        if (cur && cur.version && cur.version !== 'builtin') return cur.version;
      }
    } catch (err) { /* fall through */ }
    try {
      if (updater.getBuiltinVersion) {
        const b = await updater.getBuiltinVersion();
        if (b && b.version) return b.version;
      }
    } catch (err) { /* fall through */ }
    return null;
  }

  async function checkForUpdate() {
    const updater = updaterPlugin();
    if (!updater) return;
    const manifest = await fetchManifest();
    if (!manifest || !manifest.version || !manifest.url) return;

    const native = await nativeVersion();
    if (manifest.min_native_version && native &&
        compareVersions(manifest.min_native_version, native) > 0) {
      showBanner(MIN_NATIVE_BANNER);
      return;
    }

    const current = await currentBundleVersion(updater);
    if (current && compareVersions(manifest.version, current) <= 0) return; // already up to date

    console.log('[ota] downloading bundle ' + manifest.version + (current ? ' (running ' + current + ')' : ''));
    const options = { url: manifest.url, version: manifest.version };
    // The plugin verifies the sha256 itself when `checksum` is provided (supported since 4.0.0).
    if (manifest.sha256) options.checksum = manifest.sha256;
    const bundle = await updater.download(options);
    if (bundle && bundle.id) {
      await updater.set({ id: bundle.id });
      console.log('[ota] bundle ' + manifest.version + ' staged; applies on next launch.');
    }
  }

  /** Called by app.js once the UI has finished initializing, on EVERY launch. This is the plugin's
   * rollback proof-of-life: a staged bundle that never calls it is reverted by the plugin. */
  function onAppReady() {
    notifiedReady = true;
    const updater = updaterPlugin();
    if (!updater) return;
    Promise.resolve(updater.notifyAppReady())
      .then(() => console.log('[ota] notifyAppReady ok'))
      .catch((err) => console.warn('[ota] notifyAppReady failed:', err && err.message));
  }

  function start() {
    if (!isNative()) return; // browser/PWA: no OTA, no plugin
    checkForUpdate().catch((err) => console.warn('[ota] update check failed:', err && err.message));
    // Safety net in case app.js's init hook is ever lost: still report readiness shortly after
    // startup so a previously applied bundle is not wrongly rolled back.
    setTimeout(() => { if (!notifiedReady) onAppReady(); }, 5000);
  }

  const OTA = { start, onAppReady, showBanner, compareVersions, checkForUpdate };

  if (typeof module !== 'undefined' && module.exports) module.exports = OTA;
  global.ShiftOTA = OTA;

  if (typeof global.document !== 'undefined' && global.document.addEventListener) {
    // Runs alongside app.js init (both hang off DOMContentLoaded); Capacitor is injected by then.
    global.document.addEventListener('DOMContentLoaded', () => { try { start(); } catch (err) { console.warn('[ota] start failed:', err); } });
  } else {
    start();
  }
})(typeof window !== 'undefined' ? window : globalThis);
