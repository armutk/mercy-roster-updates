/**
 * config.js — the only place the public identity lives.
 * TODO(Ahmed): choose a final public app name with NO employer or software-vendor trademark
 * (no "Mercy", "Allocate", "RosterOn", "RLDatix", "Employee Online"). Change `name` here, then
 * the same string in index.html <title>, manifest.webmanifest, capacitor.config.json (appName),
 * android strings.xml and the iOS display name (see docs/RELEASE.md checklist).
 */
(function (global) {
  'use strict';
  global.APP_CONFIG = {
    name: 'Shift Pocket OTA1', // PLACEHOLDER public name
    // Hosted privacy policy URL (Ahmed to host src/data/privacy-policy.md). A bundled copy is always
    // viewable in-app, offline.
    privacyPolicyUrl: '',
    disclaimer: 'Pay figures are estimates from published enterprise-agreement rates, not payroll or financial advice. Always check your payslip.',
    // OTA update manifest (self-hosted Capgo/manual mode). The native app fetches this at startup
    // to find newer web bundles; see src/js/ota.js and docs/RELEASE.md.
    otaManifestUrl: 'https://armutk.github.io/mercy-roster-updates/latest.json',
  };
})(typeof window !== 'undefined' ? window : globalThis);
