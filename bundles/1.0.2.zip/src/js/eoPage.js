/**
 * eoPage.js — page recognition + login helpers for Employee Online (EO).
 *
 * One source, two users:
 *  1. Injected into the native WebView that loads EO (Android WebView / iOS WKWebView).
 *     The native plugin calls ShiftEO.inspect() after each page load and
 *     ShiftEO.fillLogin(user, pass) on the login page.
 *  2. Node tests (pure functions: classifyPage, headerDates).
 *
 * Ported from my-roster's tools/fetch_rosteron.js (selectors/regexes and exit-code design).
 * Nothing here talks to the network or stores anything.
 */
(function (global) {
  'use strict';

  const BASE = 'https://mha.allocate-cloud.com.au/MHAPROD/Mobile';
  const LOGIN_URL = BASE + '/Account/Login';
  const ROSTER_URL = BASE + '/Roster';

  const MFA_RE = /captcha|recaptcha|hcaptcha|verification code|one[- ]time (pass)?code|two[- ]factor|2fa|multi[- ]factor|authenticator|security code|verify (it'?s|that it is) you|enter the code/i;
  // Only "you must change it now" phrases: the signed-in menu always has a "Change Password" link.
  const EXPIRED_RE = /password (has )?expired|expired password|password must be changed|must change your password/i;
  const HEADER_RE = /^([A-Z][a-z]{2})\s+(\d{2})\/(\d{2})\/(\d{4})\s*-\s*(.+)$/;

  /**
   * classifyPage({ url, text, hasPasswordInput, hasCaptchaFrame }) ->
   *   'login' | 'mfa' | 'expired' | 'roster' | 'home' | 'other'
   */
  function classifyPage(p) {
    const url = p.url || '';
    const text = p.text || '';
    if (/passwordexpired|changepassword/i.test(url) || (EXPIRED_RE.test(text) && p.hasPasswordInput)) return 'expired';
    if (p.hasCaptchaFrame || MFA_RE.test(text)) return 'mfa';
    const loginish = /\/account\/login/i.test(url) ||
      (/user ?name/i.test(text) && /password/i.test(text) && /log ?in/i.test(text));
    if (loginish) return 'login';
    if (/\/roster/i.test(url) && /^\s*Roster\s*$/m.test(text)) return 'roster';
    if (/\/mobile\/?(home\/?)?(\?.*)?$/i.test(url)) return 'home';
    return 'other';
  }

  /** Dates (ISO) of every shift header in the page text, for paging and sanity checks. */
  function headerDates(text) {
    const out = [];
    String(text || '').split(/\r?\n/).forEach((l) => {
      const m = HEADER_RE.exec(l.trim());
      if (m) out.push(`${m[4]}-${m[3]}-${m[2]}`);
    });
    return out;
  }

  /* ----------------------- DOM side (runs inside EO) ----------------------- */

  function inspect() {
    const d = global.document;
    const text = d.body ? d.body.innerText || '' : '';
    const info = {
      url: global.location.href,
      text,
      hasPasswordInput: !!d.querySelector('input[type=password]'),
      hasCaptchaFrame: !!d.querySelector('iframe[src*="captcha"], iframe[title*="captcha" i], .g-recaptcha, .h-captcha'),
      pageLinks: Array.prototype.map.call(d.querySelectorAll('a[href*="pageNo="]'), (a) => a.getAttribute('href')),
    };
    info.kind = classifyPage(info);
    info.dates = headerDates(text);
    info.error = Array.prototype.map
      .call(d.querySelectorAll('.validation-summary-errors, .field-validation-error, .error, [role=alert]'), (e) => e.innerText)
      .join(' ').trim().slice(0, 200);
    return JSON.stringify(info);
  }

  function labelled(re) {
    const d = global.document;
    const labels = Array.prototype.slice.call(d.querySelectorAll('label'));
    for (const l of labels) {
      if (re.test(l.innerText || '')) {
        const id = l.getAttribute('for');
        const el = id ? d.getElementById(id) : l.querySelector('input');
        if (el) return el;
      }
    }
    return null;
  }

  function setValue(el, v) {
    const setter = Object.getOwnPropertyDescriptor(Object.getPrototypeOf(el), 'value');
    if (setter && setter.set) setter.set.call(el, v); else el.value = v;
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
  }

  /** Fill and submit the EO login form. Returns 'submitted' or the reason it could not. */
  function fillLogin(user, pass) {
    const d = global.document;
    const passBox = d.querySelector('input[type=password]');
    const userBox = labelled(/user ?name|employee|login/i) ||
      d.querySelector('input[name*=user i], input[id*=user i], input[type=text]');
    if (!userBox || !passBox) return 'form-not-found';
    setValue(userBox, user);
    setValue(passBox, pass);
    const form = passBox.form;
    const btn = (form && form.querySelector('button[type=submit], input[type=submit]')) ||
      Array.prototype.find.call(d.querySelectorAll('button, input[type=button], input[type=submit]'),
        (b) => /log ?in|sign ?in/i.test(b.innerText || b.value || ''));
    if (!btn) return 'button-not-found';
    btn.click();
    return 'submitted';
  }

  /** Best-effort: click the "Roster" link from the signed-in home page. */
  function openRosterLink() {
    const a = Array.prototype.find.call(global.document.querySelectorAll('a'), (x) => /^\s*roster\s*$/i.test(x.innerText || ''));
    if (!a) return false;
    a.click();
    return true;
  }

  function logout() {
    const a = Array.prototype.find.call(global.document.querySelectorAll('a'), (x) => /log ?(out|off)|sign ?out/i.test(x.innerText || ''));
    if (a) a.click();
    return !!a;
  }

  const api = { BASE, LOGIN_URL, ROSTER_URL, MFA_RE, EXPIRED_RE, classifyPage, headerDates, inspect, fillLogin, openRosterLink, logout };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.ShiftEO = api;
})(typeof window !== 'undefined' ? window : globalThis);
