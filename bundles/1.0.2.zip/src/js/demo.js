/**
 * demo.js — built-in DEMO MODE: a fictional roster and a made-up pay rate, usable with no
 * login. Required so app-store reviewers (and curious new users) can see every screen
 * without a hospital account. Nothing here is real: the ward is fictional and the $40.00
 * rate is invented (the manual-rate path), not any agreement rate.
 *
 * The roster is generated as sign-in-site-style text and pushed through the real parser, so
 * the demo also exercises the same code path as a real import.
 */
(function (global) {
  'use strict';

  const DOW = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const p2 = (n) => String(n).padStart(2, '0');

  // Repeating 14-day pattern from "today": [offset, start, end, label]
  const PATTERN = [
    [0, '07:00', '15:30', 'Early'], [1, '07:00', '15:30', 'Early'], [2, '13:00', '21:30', 'Late'],
    [4, '13:00', '21:30', 'Late'], [5, '13:00', '21:30', 'Late'], [8, '21:00', '07:30', 'Night'],
    [9, '21:00', '07:30', 'Night'], [12, '07:00', '15:30', 'Early'], [13, '07:00', '15:30', 'Early'],
  ];

  function demoText(todayIso, weeks) {
    const [y, m, d] = todayIso.split('-').map(Number);
    const lines = [];
    for (let w = 0; w < (weeks || 6) / 2; w++) {
      for (const [off, st, en, label] of PATTERN) {
        const dt = new Date(Date.UTC(y, m - 1, d + w * 14 + off));
        lines.push(`${DOW[dt.getUTCDay()]} ${p2(dt.getUTCDate())}/${p2(dt.getUTCMonth() + 1)}/${dt.getUTCFullYear()} - Demo Ward (fictional)`);
        lines.push(`${st} - ${en}`);
        lines.push(label);
        lines.push('Demo Nurse');
      }
    }
    return lines.join('\n');
  }

  function build(todayIso) {
    const parse = global.RosterParser.parseRosterText(demoText(todayIso, 8), { role: 'nurse' });
    const shifts = parse.shifts.map((s) => { const c = { ...s }; delete c._review; return c; });
    return {
      profile: {
        demo: true, role: 'nurse', employmentType: 'part-time', classification: '', classificationLabel: 'Demo (fictional)',
        manualBaseRate: 40, contractedWeeklyHours: 32, fortnightAnchor: null, leaveAnchor: null, createdAt: todayIso,
      },
      roster: { shifts, meta: { unit: 'Demo Ward (fictional)', lastSync: new Date().toISOString(), source: 'demo' } },
    };
  }

  const api = { demoText, build };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.DemoData = api;
})(typeof window !== 'undefined' ? window : globalThis);
