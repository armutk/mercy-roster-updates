/**
 * ui.js — onboarding, sync, settings and payslip-check screens (window.ShiftUI).
 *
 * PROGRESSIVE onboarding, all on-device:
 *   Tier 1  Roster   — EO login only: calendar, next shift, list, stats.
 *   Tier 2  Pay      — classification (or a manual base rate) + employment type.
 *   Tier 3  Verified — a payslip read on the device cross-checks the estimate.
 * The user can stop after any tier and add the next later from Settings.
 */
(function (global) {
  'use strict';

  const $ = (id) => document.getElementById(id);
  const esc = (s) => String(s == null ? '' : s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const app = () => global.ShiftApp;
  const todayIso = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };

  /* ----------------------------- overlay shell ----------------------------- */

  function overlay(html, opts) {
    let o = $('flowOverlay');
    if (!o) {
      o = document.createElement('div');
      o.id = 'flowOverlay';
      o.className = 'flow-overlay';
      document.body.appendChild(o);
    }
    o.innerHTML = `<div class="flow-panel">${(opts && opts.closable) ? '<button class="flow-close" id="flowClose" aria-label="Close">✕</button>' : ''}${html}</div>`;
    o.classList.add('open');
    const c = $('flowClose');
    if (c) c.addEventListener('click', closeOverlay);
    o.scrollTop = 0;
    return o;
  }
  function closeOverlay() {
    const o = $('flowOverlay');
    if (o) { o.classList.remove('open'); o.innerHTML = ''; }
  }

  /* ------------------------------ tier summary ------------------------------ */

  function tierState(profile, provider, payslip) {
    return {
      roster: true,
      pay: !!(provider && provider.available),
      verified: !!payslip,
    };
  }

  function tierCards(profile, provider, payslip) {
    const t = tierState(profile, provider, payslip);
    const doctor = profile && profile.role === 'doctor';
    const row = (n, title, body, on, note) => `
      <div class="tier-row ${on ? 'on' : ''}">
        <div class="tier-n">${on ? '✓' : n}</div>
        <div><strong>${title}</strong><div class="pay-note" style="margin:2px 0 0;">${body}</div>${note ? `<div class="pay-note" style="margin:2px 0 0;">${note}</div>` : ''}</div>
      </div>`;
    return `<div class="card tier-card">
      ${row(1, 'Roster', 'Next shift, roster list, calendar and stats. Needs only your Roster site login.', t.roster)}
      ${row(2, 'Pay estimate', doctor ? "Doctors: coming soon — medical officers' EA not yet encoded." : 'Your classification (or just your hourly rate) turns the roster into an estimated gross, with penalties and allowances.', t.pay && !doctor)}
      ${row(3, 'Verified', doctor ? 'Not available until the medical EA is encoded.' : 'Add a payslip (read on this phone, never uploaded) to cross-check the estimate against real pay and spot allowances the roster cannot show.', t.verified && !doctor)}
    </div>`;
  }

  /* -------------------------------- onboarding ------------------------------- */

  const draft = { role: null, user: '', pass: '', employmentType: 'part-time', classification: '', manualRate: '', hours: '' };

  function openOnboarding() {
    draft.role = null;
    stepRole();
  }

  function stepRole() {
    overlay(`
      <h1 class="flow-h">${esc(global.APP_CONFIG.name)}</h1>
      <p class="flow-sub">Your roster and pay estimate, kept on <strong>your phone only</strong>. No accounts, no server, nothing uploaded.</p>
      <div class="flow-choices">
        <button class="flow-choice" data-role="nurse"><strong>Nurse / Midwife</strong><span>Roster + pay estimate</span></button>
        <button class="flow-choice" data-role="doctor"><strong>Doctor</strong><span>Roster, calendar, stats. Pay coming soon.</span></button>
      </div>
      <button class="btn" id="obDemo" style="width:100%;margin-top:6px;">Try demo mode (fictional data, no login)</button>
      <p class="pay-note">An independent app for hospital clinical staff. Not affiliated with or endorsed by any employer or software vendor. <a href="#" id="obPriv">Privacy policy</a></p>`);
    $('obDemo').addEventListener('click', startDemo);
    $('obPriv').addEventListener('click', (e) => { e.preventDefault(); openPrivacy(); });
    let taps = 0;
    document.querySelector('.flow-h').addEventListener('click', () => { if (++taps >= 3) startDemo(); });
    document.querySelectorAll('.flow-choice').forEach((b) => b.addEventListener('click', () => { draft.role = b.dataset.role; stepLogin(); }));
  }

  function stepLogin() {
    const native = global.Native.isNative();
    overlay(`
      <h1 class="flow-h">Step 1 \u00b7 Sign in to your roster site</h1>
      ${native ? `
        <p class="flow-sub">Tap <strong>Get my roster</strong> and your hospital's own sign-in page opens inside the app. <strong>You type your own login there</strong>, exactly as in a browser. The app then reads your roster on this phone and keeps it here.</p>
        <p class="pay-note">Optional: in Settings you can have the phone remember your login (${global.Native.platform() === 'ios' ? 'iOS Keychain' : 'Android Keystore'}) so sign-in is automatic. It is off by default, and your login is never sent anywhere except your hospital's own sign-in page.</p>
      ` : `
        <p class="flow-sub">This is the browser version. A web page cannot sign in to your hospital's roster site for you (the browser blocks it), so <strong>no login is asked for or stored here</strong>. You will paste your roster text instead. For automatic sync, install the Android or iOS app.</p>
      `}
      <div class="edit-actions">
        <button class="btn primary" id="obNext">Continue</button>
        <button class="btn" id="obBack">Back</button>
      </div>`);
    $('obBack').addEventListener('click', stepRole);
    $('obNext').addEventListener('click', () => (draft.role === 'doctor' ? finishOnboarding() : stepPay()));
  }

  function classificationSelect(ea, current) {
    const opts = global.PayRegistry.classificationOptions(ea);
    return `<select id="obClass"><option value="">Choose…</option>${opts.map((o) => `<option value="${esc(o.key)}"${o.key === current ? ' selected' : ''}>${esc(o.label)}${o.code ? ' (' + esc(o.code) + ')' : ''}${o.verified ? '' : ' — unverified'}</option>`).join('')}</select>`;
  }

  async function stepPay() {
    const idx = await global.PayRegistry.loadIndex();
    const ea = await global.PayRegistry.loadEa(idx.nurse);
    const partial = !ea || ea.status !== 'complete';
    overlay(`
      <h1 class="flow-h">Step 2 · Pay estimate <em>(optional)</em></h1>
      <p class="flow-sub">${esc(global.APP_CONFIG.disclaimer)} Tell the app your classification, or just your hourly rate. Penalties are percentages, so a base rate is enough for a good estimate. Skip this to use the roster only; add it later in Settings.</p>
      <label class="field"><span>Employment type</span>
        <select id="obEmp">
          <option value="full-time"${draft.employmentType === 'full-time' ? ' selected' : ''}>Full-time</option>
          <option value="part-time"${draft.employmentType === 'part-time' ? ' selected' : ''}>Part-time</option>
          <option value="casual"${draft.employmentType === 'casual' ? ' selected' : ''}>Casual</option>
        </select></label>
      <label class="field"><span>Classification / pay point</span>${classificationSelect(ea, draft.classification)}
        ${partial ? '<small class="hint">Only some classifications are loaded so far. If yours is missing, enter your hourly rate below.</small>' : ''}</label>
      <label class="field"><span>Or your base hourly rate ($) <em>(overrides the table)</em></span><input id="obRate" type="number" step="0.0001" min="0" inputmode="decimal" value="${esc(draft.manualRate)}" placeholder="e.g. from your payslip"></label>
      <label class="field"><span>Average contracted hours per week</span><input id="obHours" type="number" step="0.5" min="0" max="80" inputmode="decimal" value="${esc(draft.hours)}" placeholder="e.g. 32"></label>
      <div class="edit-actions">
        <button class="btn primary" id="obPayNext">Continue</button>
        <button class="btn" id="obPaySkip">Skip — roster only</button>
        <button class="btn" id="obPayBack">Back</button>
      </div>`);
    $('obPayBack').addEventListener('click', stepLogin);
    const take = () => {
      draft.employmentType = $('obEmp').value;
      draft.classification = $('obClass').value;
      draft.manualRate = $('obRate').value;
      draft.hours = $('obHours').value;
    };
    $('obPaySkip').addEventListener('click', () => { draft.classification = ''; draft.manualRate = ''; finishOnboarding(); });
    $('obPayNext').addEventListener('click', () => { take(); finishOnboarding(); });
  }

  async function finishOnboarding() {
    const idx = await global.PayRegistry.loadIndex();
    const ea = draft.role === 'nurse' ? await global.PayRegistry.loadEa(idx.nurse) : null;
    const cls = ea && ea.classifications && ea.classifications[draft.classification];
    const profile = {
      role: draft.role,
      employmentType: draft.employmentType,
      classification: draft.classification || '',
      classificationLabel: cls ? cls.label : '',
      manualBaseRate: Number(draft.manualRate) > 0 ? Number(draft.manualRate) : null,
      contractedWeeklyHours: Number(draft.hours) > 0 ? Number(draft.hours) : null,
      fortnightAnchor: null,
      leaveAnchor: null,
      createdAt: todayIso(),
    };
    global.Store.saveProfile(profile);
    await app().reload();
    overlay(`
      <h1 class="flow-h">You're set up</h1>
      ${tierCards(profile, app().getProvider(), null)}
      <p class="pay-note">Everything above is stored on this phone. Add the next step any time in Settings.</p>
      <div class="edit-actions">
        <button class="btn primary" id="obGetRoster">Get my roster</button>
        <button class="btn" id="obLater">Later</button>
      </div>`);
    $('obGetRoster').addEventListener('click', () => openSync());
    $('obLater').addEventListener('click', closeOverlay);
  }

  /* ----------------------------------- sync ---------------------------------- */

  const CODE_MSG = {
    2: 'The roster site rejected the login. Check your details and try again.',
    3: 'Sign-in was cancelled or no login was entered.',
    4: 'The roster site asked for extra verification (captcha / MFA). Complete it in the sign-in window and try again.',
    5: 'The roster site says your password has expired. Change it on the roster site itself, then sync again.',
    6: 'The roster site looks different from what this app expects, so nothing was saved. Use "Paste roster" instead and report the change.',
  };

  function openSync() {
    const native = global.Native.isNative();
    overlay(`
      <h1 class="flow-h">Get my roster</h1>
      ${native ? `
        <p class="flow-sub">The app opens your hospital's own sign-in page inside the app. Type your login there; the app then reads your roster on this phone and keeps it here.</p>
        <div class="edit-actions"><button class="btn primary" id="syncNative">Sign in and sync</button></div>
        <div id="syncStatus" class="pay-note"></div>
        <hr class="flow-hr">` : `
        <p class="flow-sub">Browser version: copy your roster from your hospital's roster site and paste it below. (The Android/iOS app does this automatically.)</p>`}
      ${pasteHelp()}
      <label class="field"><span>Paste roster text</span><textarea id="syncPaste" rows="6" placeholder="Wed 26/08/2026 - Ward name&#10;07:00 - 15:30&#10;..."></textarea></label>
      <div class="edit-actions">
        <button class="btn ${native ? '' : 'primary'}" id="syncPasteGo">Read pasted roster</button>
        <button class="btn" id="syncCancel">Close</button>
      </div>
      <div id="syncResult"></div>`, { closable: true });
    $('syncCancel').addEventListener('click', () => { global.Native.cancelSync(); closeOverlay(); });
    $('syncPasteGo').addEventListener('click', () => processText($('syncPaste').value, 'paste'));
    if (native) {
      $('syncNative').addEventListener('click', async () => {
        const st = $('syncStatus');
        const lock = global.ShiftSyncLock;
        if (lock && !lock.tryAcquire()) { st.textContent = 'A sync is already running. Try again in a moment.'; return; }
        st.textContent = 'Starting…';
        $('syncNative').disabled = true;
        let r;
        try { r = await global.Native.startSync((stage) => { st.textContent = stage; }); }
        finally { if (lock) lock.release(); }
        $('syncNative').disabled = false;
        if (!r.ok) {
          st.innerHTML = `<span class="hint warn">${esc(CODE_MSG[r.code] || r.error || 'Sync failed.')}</span>`;
          return;
        }
        st.textContent = 'Read your roster. Checking it…';
        processText(r.text, 'eo');
      });
    }
  }

  function pasteHelp() {
    return `<details class="pay-note"><summary>How to copy it from your hospital's roster site</summary>
      <ol style="margin:6px 0 0 18px;padding:0;">
        <li>Open your hospital's roster site in your browser and sign in.</li>
        <li>Open <strong>Roster</strong> (the list view).</li>
        <li>Select all, copy, and paste here. Repeat for more pages.</li>
      </ol></details>`;
  }

  function processText(text, source) {
    const out = $('syncResult');
    const stored = global.Store.getRoster();
    const res = global.RosterParser.prepareImport(text, {
      role: app().getProfile().role,
      existing: stored.shifts,
      todayIso: todayIso(),
    });
    const d = res.merge.diff;
    if (!res.canSave) {
      out.innerHTML = `<div class="pay-callout warn"><strong>Nothing was saved</strong>${res.guards.hard.map((h) => `<p style="margin:6px 0 0;">${esc(h)}</p>`).join('')}</div>`;
      return;
    }
    const lines = [
      `<strong>${res.parse.stats.shifts} shifts</strong> read (${esc(res.parse.stats.first)} to ${esc(res.parse.stats.last)}).`,
      `${d.added.length} new · ${d.changed.length} changed · ${d.removed.length} removed.`,
    ];
    const list = (title, items, fn) => (items.length ? `<p class="pay-note" style="margin:6px 0 0;"><strong>${title}</strong><br>${items.slice(0, 8).map(fn).join('<br>')}${items.length > 8 ? `<br>…and ${items.length - 8} more` : ''}</p>` : '');
    const sh = (s) => `${esc(s.date)} ${esc(s.start)}-${esc(s.end)}`;
    out.innerHTML = `<div class="card">
      <p style="margin:0;">${lines.join('<br>')}</p>
      ${list('Changed', d.changed, (c) => `${sh(c.before)} → ${sh(c.after)}`)}
      ${list('Removed', d.removed, sh)}
      ${res.guards.soft.length ? `<div class="pay-callout warn"><strong>Please check</strong>${res.guards.soft.map((x) => `<p style="margin:6px 0 0;">${esc(x)}</p>`).join('')}</div>` : ''}
      <div class="edit-actions" style="margin-top:12px;">
        <button class="btn primary" id="syncSave">${res.needsConfirm ? 'Save anyway' : 'Save to this phone'}</button>
      </div></div>`;
    $('syncSave').addEventListener('click', async () => {
      const units = res.parse.shifts.map((s) => s.unit).filter(Boolean);
      global.Store.saveRoster({
        shifts: res.merge.merged,
        meta: { unit: units[units.length - 1] || (stored.meta && stored.meta.unit) || '', lastSync: new Date().toISOString(), source },
      });
      await app().reload();
      closeOverlay();
    });
  }

  /* --------------------------------- settings -------------------------------- */

  let settingsFocus = null;

  function openSettings(section) {
    settingsFocus = section || null;
    const nav = document.querySelector('.nav-btn[data-view="home"]');
    document.querySelectorAll('.view').forEach((v) => v.classList.remove('active'));
    $('view-settings').classList.add('active');
    document.querySelectorAll('.nav-btn').forEach((b) => b.classList.remove('active'));
    renderSettings();
    if (nav) window.scrollTo({ top: 0 });
  }

  async function renderSettings() {
    const body = $('settingsBody');
    if (!body) return;
    const profile = app().getProfile();
    if (!profile) { body.innerHTML = '<div class="card"><button class="btn primary" id="setStart">Set up</button></div>'; $('setStart').addEventListener('click', openOnboarding); return; }
    const provider = app().getProvider();
    const payslip = await global.Store.getPayslip();
    const native = global.Native.isNative();
    const cred = native ? await global.Native.hasCredentials().catch(() => ({ has: false })) : { has: false };
    const doctor = profile.role === 'doctor';
    const ea = provider && provider.ea;
    const stored = global.Store.getRoster();
    const L = global.LeaveRules.latestAnchor();

    body.innerHTML = `
      <div class="section-title" style="margin-top:4px;">What's unlocked</div>
      ${tierCards(profile, provider, payslip)}

      <div class="section-title">Roster</div>
      <div class="card">
        ${profile.demo ? '<div class="pay-callout warn"><strong>Demo mode</strong><p style="margin:6px 0 0;">Everything here is fictional. Use "Sign out and erase all data" to leave demo mode.</p></div>' : ''}
        <div class="pay-line"><span class="pay-line-label">Last sync</span><span class="pay-line-value">${stored.meta && stored.meta.lastSync ? esc(stored.meta.lastSync.slice(0, 16).replace('T', ' ')) : 'never'}</span></div>
        <div class="pay-line"><span class="pay-line-label">Shifts on this phone</span><span class="pay-line-value">${stored.shifts.length}</span></div>
        <div class="edit-actions" style="margin-top:12px;"><button class="btn primary" id="setSync">Sync / paste roster</button></div>
      </div>

      <div class="section-title">Auto sign-in (optional)</div>
      <div class="card">
        ${native ? `
          <p class="pay-note" style="margin-top:0;">${cred.has ? `Saved in the ${global.Native.platform() === 'ios' ? 'Keychain' : 'Android Keystore'} (${esc(cred.userMasked || '')}).` : 'Off \u2014 you type your login on the sign-in page each time it is needed.'} Used only to sign in to your hospital's roster site on this phone.</p>
          <label class="field"><span>Employee number</span><input id="setUser" autocomplete="off"></label>
          <label class="field"><span>Password</span><input id="setPass" type="password" autocomplete="off"></label>
          <div class="edit-actions"><button class="btn primary" id="setSaveCred">Remember my login</button>${cred.has ? '<button class="btn danger" id="setDelCred">Remove login</button>' : ''}</div>
          <div id="setCredMsg" class="hint"></div>` :
          '<p class="pay-note" style="margin:0;">The browser version never stores a login. Use the Android or iOS app for sync.</p>'}
      </div>

      <div class="section-title" id="sec-pay">Pay estimate</div>
      <div class="card">
        ${doctor ? `<div class="pay-callout"><strong>Coming soon</strong><p style="margin:6px 0 0;">${esc(global.PayRegistry.DOCTOR_NOTICE)}</p></div>` : `
        <label class="field"><span>Employment type</span><select id="setEmp">
          ${['full-time', 'part-time', 'casual'].map((t) => `<option value="${t}"${profile.employmentType === t ? ' selected' : ''}>${t}</option>`).join('')}</select></label>
        <label class="field"><span>Classification / pay point</span>${classificationSelect(ea, profile.classification).replace('id="obClass"', 'id="setClass"')}</label>
        <label class="field"><span>Base hourly rate ($) <em>(overrides the table)</em></span><input id="setRate" type="number" step="0.0001" min="0" inputmode="decimal" value="${profile.manualBaseRate || ''}"></label>
        <label class="field"><span>Average contracted hours per week</span><input id="setHours" type="number" step="0.5" min="0" max="80" value="${profile.contractedWeeklyHours || ''}"></label>
        <label class="field"><span>Pay fortnight starts (a Monday)</span><input id="setFn" type="date" value="${esc(profile.fortnightAnchor || '2026-09-07')}"></label>
        <div class="edit-actions"><button class="btn primary" id="setSavePay">Save pay settings</button></div>
        <p class="pay-note">${provider.available ? esc(provider.notice || 'Pay estimate is on.') : esc(provider.reason || '')}</p>`}
      </div>

      ${doctor ? '' : `
      <div class="section-title" id="sec-leave">Leave balance</div>
      <div class="card">
        <p class="pay-note" style="margin-top:0;">From your latest payslip (hours). Projected forward from your roster. Stored on this phone.</p>
        <label class="field"><span>Balance as at (pay period end)</span><input id="lvAt" type="date" value="${esc(L ? L.asAt : '')}"></label>
        <div class="field-row">
          <label class="field"><span>Annual leave (h)</span><input id="lvAL" type="number" step="0.01" value="${L ? L.balances.AL : ''}"></label>
          <label class="field"><span>Personal/sick (h)</span><input id="lvSL" type="number" step="0.01" value="${L ? L.balances.SL : ''}"></label>
        </div>
        <div class="edit-actions"><button class="btn primary" id="lvSave">Save balances</button>${L ? '<button class="btn" id="lvClear">Clear</button>' : ''}</div>
      </div>

      <div class="section-title" id="sec-payslip">Check against a payslip (Tier 3)</div>
      <div class="card">
        <p class="pay-note" style="margin-top:0;">The payslip is read on this phone${global.Native.ocrSupported() ? ' (on-device text recognition)' : ''} and never uploaded. Only the parsed numbers are kept, in ${native ? 'secure storage' : 'this browser (no secure store here)'}.</p>
        ${global.Native.ocrSupported() ? '<label class="field"><span>Photo of payslip</span><input id="psFile" type="file" accept="image/*"></label>' : ''}
        <label class="field"><span>Or paste payslip text</span><textarea id="psText" rows="5"></textarea></label>
        <div class="edit-actions"><button class="btn primary" id="psGo">Read and compare</button>${payslip ? '<button class="btn danger" id="psClear">Forget saved payslip</button>' : ''}</div>
        <div id="psResult">${payslip ? savedPayslipHtml(payslip) : ''}</div>
      </div>`}

      <div class="section-title">Privacy and about</div>
      <div class="card">
        <p class="pay-note" style="margin-top:0;"><strong>${esc(global.APP_CONFIG.disclaimer)}</strong></p>
        <div class="edit-actions"><button class="btn" id="setPriv">Privacy policy</button></div>
        <p class="pay-note" style="margin-top:0;">Roster, settings, login and payslip numbers live only on this phone. There is no server and no account. Nothing is sent anywhere except your own sign-in, direct to your hospital's sign-in page.</p>
        <div class="edit-actions"><button class="btn danger" id="setWipe">Sign out and erase all data</button></div>
      </div>`;

    wireSettings(profile, provider, ea);
    if (settingsFocus) {
      const t = $('sec-' + settingsFocus);
      if (t) t.scrollIntoView();
      settingsFocus = null;
    }
  }

  function savedPayslipHtml(p) {
    return `<p class="pay-note">Saved check: ${esc(p.periodStart)} to ${esc(p.periodEnd)}, gross $${Number(p.gross).toFixed(2)} — ${esc(p.status || 'unchecked')} (${esc(p.checkedAt)}).</p>`;
  }

  function wireSettings(profile, provider, ea) {
    const on = (id, fn) => { const e = $(id); if (e) e.addEventListener('click', fn); };
    on('setSync', openSync);
    on('setPriv', openPrivacy);

    on('setSaveCred', async () => {
      const u = $('setUser').value.trim(); const p = $('setPass').value;
      if (!u || !p) { $('setCredMsg').textContent = 'Enter both fields.'; return; }
      await global.Native.saveCredentials(u, p);
      $('setPass').value = ''; $('setUser').value = '';
      renderSettings();
    });
    on('setDelCred', async () => { await global.Native.clearCredentials(); renderSettings(); });

    on('setSavePay', async () => {
      const cls = ea && ea.classifications && ea.classifications[$('setClass').value];
      const next = {
        ...profile,
        employmentType: $('setEmp').value,
        classification: $('setClass').value,
        classificationLabel: cls ? cls.label : '',
        manualBaseRate: Number($('setRate').value) > 0 ? Number($('setRate').value) : null,
        contractedWeeklyHours: Number($('setHours').value) > 0 ? Number($('setHours').value) : null,
        fortnightAnchor: $('setFn').value || null,
      };
      global.Store.saveProfile(next);
      await app().reload();
      renderSettings();
    });

    on('lvSave', async () => {
      const al = parseFloat($('lvAL').value); const sl = parseFloat($('lvSL').value); const at = $('lvAt').value;
      if (!at || !isFinite(al) || !isFinite(sl)) return;
      global.Store.saveProfile({ ...profile, leaveAnchor: { asAt: at, AL: al, SL: sl, LSL: null, ALW: null } });
      await app().reload();
      renderSettings();
    });
    on('lvClear', async () => { global.Store.saveProfile({ ...profile, leaveAnchor: null }); await app().reload(); renderSettings(); });

    on('psGo', async () => {
      const out = $('psResult');
      let text = $('psText').value;
      const f = $('psFile') && $('psFile').files[0];
      try {
        if (f) {
          out.textContent = 'Reading the photo on this phone…';
          const url = await new Promise((res, rej) => { const r = new FileReader(); r.onload = () => res(r.result); r.onerror = rej; r.readAsDataURL(f); });
          text = await global.Native.recognizeText(url);
        }
      } catch (e) { out.innerHTML = '<span class="hint warn">Could not read the photo. Paste the text instead.</span>'; return; }
      const ps = global.Payslip.parsePayslipText(text);
      if (!provider.available) { out.innerHTML = `<div class="pay-callout warn"><strong>Set up pay first</strong><p>${esc(provider.reason || '')}</p></div>`; return; }
      const check = global.Payslip.crossCheck(ps, app().getShifts(), app().getShiftTypes(), provider);
      out.innerHTML = checkHtml(ps, check);
      const keep = $('psKeep');
      if (keep) keep.addEventListener('click', async () => { await global.Store.savePayslip(global.Payslip.toSummary(ps, check)); renderSettings(); });
    });
    on('psClear', async () => { await global.Store.clearPayslip(); renderSettings(); });

    on('setWipe', async () => {
      if (!confirm('Delete your roster, settings, login and payslip data from this phone?')) return;
      await global.Store.wipeAll();
      await app().reload();
      openOnboarding();
    });
  }

  function checkHtml(ps, c) {
    const money = (n) => '$' + Number(n).toFixed(2);
    const warn = ps.warnings.length ? `<div class="pay-callout warn"><strong>Could not read everything</strong>${ps.warnings.map((w) => `<p style="margin:6px 0 0;">${esc(w)}</p>`).join('')}</div>` : '';
    if (c.status === 'unavailable') return warn + `<div class="pay-callout warn"><p>${esc(c.reason)}</p></div>`;
    return warn + `<div class="card">
      <div class="pay-line"><span class="pay-line-label">Payslip gross</span><span class="pay-line-value">${money(c.gross)}</span></div>
      <div class="pay-line"><span class="pay-line-label">App estimate (${c.periodShifts} shifts)</span><span class="pay-line-value">${money(c.estimate)}</span></div>
      <div class="pay-line"><span class="pay-line-label">Difference</span><span class="pay-line-value">${money(c.difference)}</span></div>
      ${c.notEstimated.length ? `<p class="pay-note"><strong>On the payslip but not in the estimate (${money(c.notEstimatedTotal)})</strong><br>${c.notEstimated.map((l) => `${esc(l.desc)} ${money(l.amount)}`).join('<br>')}</p>` : ''}
      ${c.discrepancies.length ? `<div class="pay-callout warn"><strong>Worth a look</strong>${c.discrepancies.map((d) => `<p style="margin:6px 0 0;">${esc(d)}</p>`).join('')}</div>` : '<div class="pay-callout"><strong>Matches</strong><p style="margin:6px 0 0;">The estimate agrees with this payslip.</p></div>'}
      <div class="edit-actions"><button class="btn primary" id="psKeep">Keep this result on my phone</button></div></div>`;
  }

  /* ------------------------------ demo + privacy ------------------------------ */

  async function startDemo() {
    await global.Store.wipeAll();
    const demo = global.DemoData.build(todayIso());
    global.Store.saveProfile(demo.profile);
    global.Store.saveRoster(demo.roster);
    await app().reload();
    overlay(`<h1 class="flow-h">Demo mode</h1>
      <p class="flow-sub">You're looking at a <strong>fictional</strong> nurse roster and a made-up pay rate, so you can try every screen without signing in. Nothing here is real, and nothing leaves this device.</p>
      <div class="edit-actions"><button class="btn primary" id="demoGo">Explore the app</button></div>`);
    $('demoGo').addEventListener('click', closeOverlay);
  }

  async function openPrivacy() {
    let text = 'Privacy policy not available offline.';
    try { const r = await fetch('src/data/privacy-policy.md'); if (r.ok) text = await r.text(); } catch (e) { /* keep default */ }
    const url = global.APP_CONFIG.privacyPolicyUrl;
    overlay(`<h1 class="flow-h">Privacy policy</h1>
      ${url ? `<p class="pay-note"><a href="${esc(url)}" target="_blank" rel="noopener">${esc(url)}</a></p>` : ''}
      <pre class="policy-text">${esc(text)}</pre>
      <div class="edit-actions"><button class="btn" id="polClose">Close</button></div>`, { closable: true });
    $('polClose').addEventListener('click', closeOverlay);
  }

  global.ShiftUI = { openOnboarding, openSync, startDemo, openPrivacy, openSettings, renderSettings, closeOverlay };
})(window);
