# EA rate tables

One JSON file per enterprise agreement, `src/data/ea/<ea-id>.json`, listed in `index.json`.
The pay engine (`src/js/payRegistry.js`) loads the table for the user's role and picks
the row for their classification. Schema:

```
{ "id", "title", "status": "partial|complete", "fullTimeWeeklyHours": 38,
  "employmentTypes": { "<type>": { "label", "verified", "hourlyDivisor"|"loadingPct", ... } },
  "classifications": { "<key>": { "label", "code", "grade", "verified", "source",
      "table": [ { "effectiveFrom": "YYYY-MM-DD", "weeklySalary": 0, "publishedHourly": 0, "note": "" } ] } } }
```

Rules: copy rates from the agreement text only, cite the source, set `verified:false` if unsure.
A classification that is absent or unverified shows "needs verification" in the app.
To add rows from the full public nurse table, add keys under `classifications`; no code change
is needed (the onboarding classification list is built from this file).
