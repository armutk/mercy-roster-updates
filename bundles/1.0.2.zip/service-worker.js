const CACHE_NAME = 'shift-pocket-0.1.0';
const APP_SHELL = [
  './',
  './index.html',
  './manifest.webmanifest',
  './src/css/style.css',
  './src/js/config.js',
  './src/js/rosterParser.js',
  './src/js/storage.js',
  './src/js/native.js',
  './src/js/ota.js',
  './src/js/payRegistry.js',
  './src/js/payslip.js',
  './src/js/demo.js',
  './src/js/ui.js',
  './src/js/app.js',
  './src/js/payRules.js',
  './src/js/payEngine.js',
  './src/js/leaveRules.js',
  './src/js/leaveEngine.js',
  './src/data/ea/index.json',
  './src/data/ea/vic-public-nurse-2024-2028.json',
  './src/data/privacy-policy.md',
  './icons/icon-192.png',
  './icons/icon-512.png',
  './icons/apple-touch-icon.png',
];

self.addEventListener('install', (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((key) => key !== CACHE_NAME).map((key) => caches.delete(key)))
    ).then(() => self.clients.claim())
  );
});

// Cache-first for app shell/data, falling back to network; network-first update-in-background for navigation.
self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;

  event.respondWith(
    caches.match(request).then((cached) => {
      const networkFetch = fetch(request)
        .then((response) => {
          if (response && response.status === 200) {
            const clone = response.clone();
            caches.open(CACHE_NAME).then((cache) => cache.put(request, clone));
          }
          return response;
        })
        .catch(() => cached);
      return cached || networkFetch;
    })
  );
});
