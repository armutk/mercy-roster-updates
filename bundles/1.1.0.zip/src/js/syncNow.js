/**
 * syncNow.js — state machine for the home-screen "Sync now" button, plus the shared sync lock.
 * Pure logic (no DOM, no storage): app.js wires it to the button and to the on-device scrape
 * (Native.startSync -> RosterParser.prepareImport -> Store.saveRoster), so Node tests can drive it.
 *
 * States: idle -> running -> success | error  (success/error behave like idle once the
 * 2-minute rate limit has passed; a "signin" error is exempt from the limit so she can retry
 * straight after signing in).
 *
 * ShiftSyncLock is the ONE lock every sync path takes (this button and the manual
 * "Get my roster" flow in ui.js), so two syncs can never run at once.
 */
(function (global) {
  'use strict';

  const RATE_LIMIT_MS = 2 * 60 * 1000;

  const MSG = {
    signin: 'Sign in to your roster site first',
    timeout: "Your roster site didn't respond, try again in a few minutes",
    other: "Couldn't sync just now, try again in a few minutes",
    busy: 'A sync is already running',
    browser: 'Sync now needs the Shift Pocket app on your phone',
  };

  function createLock() {
    let held = false;
    return {
      tryAcquire() { if (held) return false; held = true; return true; },
      release() { held = false; },
      isHeld() { return held; },
    };
  }

  /** Friendly kind for a failed Native.startSync result ({ code, stage, error }). */
  function classifyFailure(r) {
    const code = r && r.code;
    if (code === 2 || code === 3 || code === 4 || code === 5) return 'signin';
    return 'timeout';
  }

  function plural(n) { return n === 1 ? '1 shift' : n + ' shifts'; }

  /**
   * deps.run(): Promise<{ ok:true, changed:number } | { ok:false, kind:'signin'|'timeout'|'other', message? }>
   * deps.now(): ms clock; deps.lock: shared lock; deps.onChange(view): called on every state change.
   */
  function create(deps) {
    const now = deps.now || Date.now;
    const lock = deps.lock;
    const rateMs = deps.rateLimitMs || RATE_LIMIT_MS;
    let state = 'idle';
    let message = '';
    let lastRunAt = null; // when the last rate-limited run finished
    let lastOkAt = null;

    function view() { return { state, message, busy: state === 'running', lastOkAt }; }
    function emit() { if (deps.onChange) deps.onChange(view()); }
    function waitMs() { return lastRunAt == null ? 0 : Math.max(0, lastRunAt + rateMs - now()); }

    async function start() {
      if (state === 'running') return { started: false, reason: 'running' };
      if (waitMs() > 0) {
        const secs = Math.ceil(waitMs() / 1000);
        message = 'Just synced. You can sync again in ' + (secs >= 60 ? Math.ceil(secs / 60) + ' min' : secs + ' sec');
        emit();
        return { started: false, reason: 'rate', waitMs: waitMs() };
      }
      if (!lock.tryAcquire()) {
        message = MSG.busy;
        emit();
        return { started: false, reason: 'busy' };
      }
      state = 'running';
      message = 'Syncing with your roster site…';
      emit();
      let r;
      try {
        r = await deps.run();
      } catch (err) {
        r = { ok: false, kind: 'other' };
      } finally {
        lock.release();
      }
      if (r && r.ok) {
        state = 'success';
        lastRunAt = lastOkAt = now();
        const n = Number(r.changed) || 0;
        message = 'Synced just now · ' + plural(n) + ' changed';
      } else {
        state = 'error';
        const kind = (r && r.kind) || 'other';
        if (kind !== 'signin') lastRunAt = now();
        message = (r && r.message) || MSG[kind] || MSG.other;
      }
      emit();
      return { started: true, state };
    }

    return { start, view, waitMs, get state() { return state; } };
  }

  const API = { RATE_LIMIT_MS, MSG, createLock, classifyFailure, create, plural };
  if (typeof module !== 'undefined' && module.exports) module.exports = API;
  global.ShiftSyncNow = API;
  if (!global.ShiftSyncLock) global.ShiftSyncLock = createLock();
})(typeof window !== 'undefined' ? window : globalThis);
