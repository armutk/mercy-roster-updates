/**
 * storage.js — everything the app remembers lives on THIS device. Nothing is sent anywhere.
 *
 *  - profile / roster / overrides: localStorage (per-origin, inside the app sandbox).
 *  - secrets (EO login, payslip data): native secure storage in the Android/iOS app
 *    (Keystore-backed AES-GCM / Keychain) through Native.secure*. In a plain browser
 *    there is no secure store, so the app does not keep the EO password at all, and a
 *    payslip summary is kept in localStorage only if the user opts in (with a warning).
 *
 * Every access is wrapped in try/catch: storage can be blocked (private mode) and the
 * app must still render.
 */
(function (global) {
  'use strict';

  const K = {
    profile: 'mercyroster-profile',
    roster: 'mercyroster-roster',
    overrides: 'mercyroster-overrides',
    theme: 'mercyroster-theme',
    payslip: 'payslip.summary', // secure key
  };
  const VERSION = 1;

  function read(key, fallback) {
    try {
      const raw = global.localStorage.getItem(key);
      return raw == null ? fallback : JSON.parse(raw);
    } catch (e) {
      return fallback;
    }
  }
  function write(key, value) {
    try {
      global.localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      return false;
    }
  }

  const Store = {
    K,
    getProfile() { return read(K.profile, null); },
    saveProfile(p) { return write(K.profile, { ...p, v: VERSION }); },
    getRoster() { return read(K.roster, { v: VERSION, shifts: [], meta: {} }); },
    saveRoster(r) { return write(K.roster, { v: VERSION, shifts: r.shifts, meta: r.meta || {} }); },
    getOverrides() { return read(K.overrides, {}); },
    saveOverrides(o) { return write(K.overrides, o); },

    /** Remove every trace of this user from the device (profile, roster, edits, secrets). */
    async wipeAll() {
      try {
        const keys = [];
        for (let i = 0; i < global.localStorage.length; i++) {
          const k = global.localStorage.key(i);
          if (k && k.indexOf('mercyroster-') === 0) keys.push(k);
        }
        keys.forEach((k) => global.localStorage.removeItem(k));
      } catch (e) { /* nothing to wipe */ }
      if (global.Native && global.Native.isNative()) await global.Native.secureClear().catch(() => {});
    },

    /* Tier-3 payslip summary (numbers only, never the image). */
    async getPayslip() {
      const N = global.Native;
      if (N && N.isNative()) {
        const v = await N.secureGet(K.payslip).catch(() => null);
        return v ? JSON.parse(v) : null;
      }
      return read('mercyroster-secret-payslip', null);
    },
    async savePayslip(summary) {
      const N = global.Native;
      if (N && N.isNative()) return N.secureSet(K.payslip, JSON.stringify(summary));
      return write('mercyroster-secret-payslip', summary);
    },
    async clearPayslip() {
      const N = global.Native;
      if (N && N.isNative()) return N.secureRemove(K.payslip);
      try { global.localStorage.removeItem('mercyroster-secret-payslip'); } catch (e) { /* ignore */ }
      return null;
    },
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = Store;
  global.Store = Store;
})(typeof window !== 'undefined' ? window : globalThis);
