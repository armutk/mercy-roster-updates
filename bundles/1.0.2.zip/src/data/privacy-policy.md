# Privacy Policy - mercy-roster

Effective: [DATE]    Developer: [LEGAL NAME / ABN]    Contact: [privacy email]

mercy-roster ("the app") is a personal productivity tool for healthcare workers. It shows your own roster in a calendar and gives you an estimate of your pay. This policy explains what the app does with your information. The short version: your data stays on your phone and we never receive it.

## 1. What the app does
You sign in to your employer's rostering website (for example RosterOn / Allocate Employee Online) by typing your own username and password into the sign-in page shown inside the app. The app then reads your own roster from that page, on your phone, and displays it. It calculates an estimated pay figure using publicly available enterprise-agreement pay rates and the settings you enter.

## 2. What we collect
We (the developer) collect nothing. The app has no developer server, no account system, no analytics, no advertising, no crash-reporting service and no third-party SDKs that send data off your device.

## 3. What is stored on your device
- Your roster shifts (dates, times, locations, shift codes), cached so the app works offline.
- Your settings (pay classification, level, allowances, preferences).
- If you choose "Remember me", your rostering username and password, stored only in the iOS Keychain / Android Keystore-backed encrypted storage. They are never written to plain files, logs or backups we control. You can turn this off and the app will ask you to sign in each time.
- Session cookies from your employer's site, held in the app's private web view storage.

## 4. Where your data goes
Your credentials and roster are sent only between your phone and your employer's rostering website, exactly as if you had signed in with a browser. We have no access to them. We do not sell, share, rent or disclose your information to anyone. If you choose to export a shift to your phone's calendar, that is a copy within your own device under your control.

## 5. Permissions
- Calendar (optional): only if you tap "Add to calendar". Used solely to write the shifts you select.
- Notifications (optional): local reminders generated on the device. No push server is used.
- Biometrics (optional): to unlock saved credentials, handled by the operating system. We never receive biometric data.

## 6. Not affiliated
mercy-roster is an independent app. It is not made, endorsed or supported by your employer, Allocate, RLDatix or any union. Product names are used only to describe compatibility. Pay figures are estimates only, are not payroll or legal advice, and may differ from your actual pay. Always check your payslip.

## 7. Security
Credentials use platform secure storage. Connections to your employer's site use HTTPS. The app does not disable certificate checks. Use a device passcode.

## 8. Retention and deletion
Everything lives on your phone. To delete it: use Settings > "Sign out and erase all data" in the app, or uninstall the app. Because we hold no copy, there is nothing for us to delete and nothing to request from us. To revoke access at your employer, change your rostering password through your employer's normal process.

## 9. Children
The app is for working adults and is not directed at children under 16.

## 10. Your rights
Because we do not hold your personal information, access and correction requests are met by the app itself, which shows everything it stores. Under the Australian Privacy Act 1988 you can still contact us with questions or complaints at [privacy email]; you may also contact the Office of the Australian Information Commissioner (oaic.gov.au).

## 11. Changes
If we ever change this policy, in particular if any data were to leave your device, we will update this page and ask for your consent in the app before it takes effect.
