/**
 * native.js — thin adapter over the Capacitor "EoBridge" plugin (Android + iOS).
 * In a plain browser/PWA every method reports "not native" and the app falls back to
 * paste/OCR import. The plugin is the ONLY code that ever uses the EO password.
 *
 * Plugin methods (implemented in native/android and native/ios):
 *   secureSet/secureGet/secureRemove/secureClear   Keystore / Keychain storage
 *       (secureGet refuses the 'eo.pass' key: JS can store the password, never read it back)
 *   hasCredentials()                               -> { has, userMasked }
 *   startSync({ pages })                           -> { ok, text } | { ok:false, code, stage, error }
 *   cancelSync()
 *   recognizeText({ image })                       -> { text }   (on-device OCR for payslips)
 * Progress events: 'syncProgress' { stage }.
 */
(function (global) {
  'use strict';

  function plugin() {
    const C = global.Capacitor;
    if (!C || !C.isNativePlatform || !C.isNativePlatform()) return null;
    return (C.Plugins && C.Plugins.EoBridge) || (C.registerPlugin ? C.registerPlugin('EoBridge') : null);
  }

  const Native = {
    isNative() { return !!plugin(); },
    platform() { return global.Capacitor && global.Capacitor.getPlatform ? global.Capacitor.getPlatform() : 'web'; },
    /** On-device OCR exists on iOS (Vision framework). Android: TODO, see docs/ARCHITECTURE.md. */
    ocrSupported() { return plugin() ? this.platform() === 'ios' : false; },
    secureSet(key, value) { return plugin().secureSet({ key, value }); },
    async secureGet(key) { const r = await plugin().secureGet({ key }); return r && r.value != null ? r.value : null; },
    secureRemove(key) { return plugin().secureRemove({ key }); },
    secureClear() { return plugin().secureClear(); },
    async saveCredentials(user, pass) {
      await plugin().secureSet({ key: 'eo.user', value: user });
      await plugin().secureSet({ key: 'eo.pass', value: pass });
    },
    async hasCredentials() {
      const p = plugin();
      if (!p) return { has: false };
      return p.hasCredentials();
    },
    clearCredentials() {
      const p = plugin();
      if (!p) return Promise.resolve();
      return Promise.all([p.secureRemove({ key: 'eo.user' }), p.secureRemove({ key: 'eo.pass' })]);
    },
    /** Resolves with { ok, text } or { ok:false, code, stage, error }. */
    async startSync(onProgress) {
      const p = plugin();
      if (!p) return { ok: false, code: 1, stage: 'platform', error: 'On-device sync needs the Android or iOS app.' };
      let handle = null;
      if (onProgress && p.addListener) handle = await p.addListener('syncProgress', (e) => onProgress(e.stage));
      try {
        return await p.startSync({ pages: 12 });
      } finally {
        if (handle && handle.remove) handle.remove();
      }
    },
    cancelSync() { const p = plugin(); return p ? p.cancelSync() : Promise.resolve(); },
    async recognizeText(imageDataUrl) {
      const p = plugin();
      if (!p) throw new Error('On-device OCR needs the Android or iOS app.');
      const r = await p.recognizeText({ image: imageDataUrl });
      return r.text || '';
    },
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = Native;
  global.Native = Native;
})(typeof window !== 'undefined' ? window : globalThis);
