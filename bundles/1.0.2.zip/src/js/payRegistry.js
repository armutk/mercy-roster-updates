/**
 * payRegistry.js — picks the pay provider for a user's role + classification.
 *
 * A "provider" is { available, reason, engine, rules, notice, ea, classification }.
 *  - nurse  -> PayEngine/PayRules (Nurses & Midwives Vic public sector EA 2024-2028),
 *              parameterised by classification row and employment type from an EA data
 *              file (src/data/ea/<ea-id>.json).
 *  - doctor -> STUB. The medical officers' EA is not encoded; no rate is invented.
 *
 * To add a second ruleset (e.g. medical officers): add an EA data file, register it in
 * src/data/ea/index.json, and add a branch in providerFor() returning its own engine.
 */
(function (global) {
  'use strict';

  const DOCTOR_NOTICE = "Coming soon — medical officers' EA not yet encoded.";
  const cache = {};

  const CATEGORY_LABEL = {
    registered_nurse_grade2: 'Registered nurse / midwife (Grade 2)',
    midwife_grade2: 'Midwife (Grade 2)',
    enrolled_nurse_or_trainee: 'Enrolled nurse / trainee',
    rn_g2_student_midwife: 'Student midwife (RN Grade 2)',
    undergraduate_student: 'Undergraduate student',
    senior_clinical_specialist_management_education: 'Senior, specialist, management, education',
    research: 'Research',
    bank: 'Bank',
  };

  /**
   * Turn the raw EA file (src/data/ea/<id>.json, schema of ea-nurse.json) into the shape the
   * registry uses. Rows whose source has a known caveat (no code printed, rows with missing
   * early steps, rows flagged in the file's `unverified` list) are marked verified:false and
   * shown as "needs verification" - never silently trusted.
   */
  function normalizeEa(raw) {
    if (!raw || !raw.baseRate) return raw && raw.classifications ? raw : null;
    const classifications = {};
    const used = new Set();
    for (const c of raw.baseRate.classifications) {
      const steps = (c.steps || []).filter((x) => x.weeklySalary != null);
      let key = `${c.code || 'NOCODE'}:${String(c.name).toUpperCase().replace(/[^A-Z0-9]+/g, '-').replace(/^-|-$/g, '')}`;
      while (used.has(key)) key += '+';
      used.add(key);
      const caveat = !c.code || /MAT&CHILD NURSE STUDENT/i.test(c.name) || steps.length < (c.steps || []).length;
      classifications[key] = {
        label: c.name, code: c.code || null, grade: c.grade || null, category: c.category,
        categoryLabel: CATEGORY_LABEL[c.category] || c.category,
        verified: !caveat && steps.length > 0,
        source: `${raw._meta.agreement}, ${raw.baseRate.source}`,
        table: steps.map((x) => ({ effectiveFrom: x.effectiveFrom, weeklySalary: x.weeklySalary, publishedHourly: x.publishedHourly, note: x.eaLabel })),
      };
    }
    const cas = raw.casual;
    return {
      id: 'vic-public-nurse-2024-2028',
      title: raw._meta.agreement,
      status: 'complete',
      fullTimeWeeklyHours: raw.ordinaryHours ? raw.ordinaryHours.fullTimeWeekly : 38,
      employmentTypes: {
        'full-time': { label: 'Full-time', verified: true, multiplier: 1, clause: 'cl 18.3' },
        'part-time': { label: 'Part-time', verified: true, multiplier: 1, clause: 'cl 18.3' },
        casual: cas
          ? { label: 'Casual', verified: true, multiplier: 1 + cas.loadingPercent / 100, clause: `cl ${cas.clause}`, note: 'Casual loading applied to the base rate. Casual overtime is not modelled.' }
          : { label: 'Casual', verified: false, note: 'Casual loading not available.' },
      },
      classifications,
      unverified: raw.unverified || [],
      coverageNote: raw._meta.mercyCoverageNote || null,
    };
  }

  async function loadEa(id, fetchFn) {
    if (!id) return null;
    if (cache[id]) return cache[id];
    const f = fetchFn || (typeof fetch === 'function' ? fetch : null);
    if (!f) return null;
    try {
      const res = await f(`src/data/ea/${id}.json`, { cache: 'no-cache' });
      if (!res.ok) return null;
      cache[id] = normalizeEa(await res.json());
      return cache[id];
    } catch (e) {
      return null;
    }
  }

  async function loadIndex(fetchFn) {
    const f = fetchFn || fetch;
    try {
      const res = await f('src/data/ea/index.json', { cache: 'no-cache' });
      return res.ok ? await res.json() : {};
    } catch (e) {
      return {};
    }
  }

  /** Classification choices for the onboarding picker (only those with rows loaded). */
  function classificationOptions(ea) {
    if (!ea || !ea.classifications) return [];
    return Object.entries(ea.classifications).map(([key, c]) => ({
      key, label: c.label, code: c.code, grade: c.grade, category: c.categoryLabel || '', verified: !!c.verified,
    }));
  }

  /**
   * providerFor(profile, ea) — profile: { role, classification, employmentType }
   * Synchronous and pure given an already-loaded `ea`.
   */
  function providerFor(profile, ea) {
    const role = profile && profile.role;
    if (role === 'doctor') {
      return { available: false, kind: 'stub', reason: DOCTOR_NOTICE, notice: DOCTOR_NOTICE };
    }
    const R = global.PayRules;
    const E = global.PayEngine;
    if (!R || !E) return { available: false, kind: 'error', reason: 'Pay engine unavailable.' };
    // Manual base rate (user-entered hourly rate) always works as a fallback/override:
    // penalties are percentages of the base rate, so the estimate does not need the full table.
    const manual = Number(profile.manualBaseRate);
    if (manual > 0) {
      R.setBaseRate({
        label: profile.classificationLabel || 'Manual base rate',
        code: null, grade: null, verified: true,
        source: 'Hourly rate entered by you',
        table: [{ effectiveFrom: '1900-01-01', weeklySalary: manual * (ea && ea.fullTimeWeeklyHours || 38), publishedHourly: manual, note: 'Entered by you' }],
      });
      return {
        available: true, kind: 'nurse', manual: true, engine: E, rules: R, ea,
        notice: 'Using the hourly rate you entered. Penalties and allowances are worked out from it.' +
          (profile.employmentType === 'casual' ? ' Casual loading is not added; enter your rate with it included.' : ''),
      };
    }
    if (!ea) {
      R.setBaseRate(null);
      return { available: false, kind: 'needs-verification', reason: 'Needs verification \u2014 the agreement rate table could not be loaded. You can enter your hourly rate in Settings.' };
    }
    const type = ea.employmentTypes && ea.employmentTypes[profile.employmentType];
    if (!type || !type.verified) {
      R.setBaseRate(null);
      return {
        available: false, kind: 'needs-verification', ea,
        reason: `Needs verification \u2014 ${(type && type.note) || 'this employment type is not encoded yet.'} You can enter your hourly rate in Settings.`,
      };
    }
    const cls = ea.classifications && ea.classifications[profile.classification];
    if (!cls || !Array.isArray(cls.table) || !cls.table.length) {
      R.setBaseRate(null);
      return {
        available: false, kind: 'needs-verification', ea,
        reason: 'Needs verification \u2014 no wage row for your classification yet. Enter your hourly rate in Settings, or wait for the rate table. Roster, calendar and stats still work.',
      };
    }
    R.setBaseRate(cls, type.multiplier);
    const notes = [];
    if (!cls.verified) notes.push('Needs verification \u2014 this classification row has a caveat in the source agreement table. Check it against your payslip.');
    if (type.note && profile.employmentType === 'casual') notes.push(type.note);
    return {
      available: true, kind: 'nurse', engine: E, rules: R, ea, classification: cls, needsVerification: !cls.verified,
      notice: notes.join(' ') || null,
    };
  }

  const api = { DOCTOR_NOTICE, normalizeEa, loadEa, loadIndex, classificationOptions, providerFor };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.PayRegistry = api;
})(typeof window !== 'undefined' ? window : globalThis);
