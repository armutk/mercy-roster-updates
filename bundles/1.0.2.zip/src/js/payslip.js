/**
 * payslip.js — Tier 3 "Verified": read a payslip ON THE DEVICE and cross-check the estimate.
 *
 * Input is plain text: either typed/pasted, or produced by on-device OCR (iOS Vision,
 * Android ML Kit) from a photo or PDF page. The image/text is never uploaded; only the
 * parsed summary (numbers) is kept, in secure storage (see storage.js).
 *
 * The parser is deliberately heuristic (payslip layouts vary). Anything it cannot read is
 * reported in `warnings` rather than guessed. TODO: tune against a few real payslip
 * layouts on a device (tests here use a synthetic sample only).
 *
 * Cross-check idea carried over from my-roster's payslip_compare.js: run the pay engine over
 * the payslip's own pay period and compare the gross and each line.
 */
(function (global) {
  'use strict';

  const num = (s) => Number(String(s).replace(/[$,\s]/g, ''));
  const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;
  const isoOf = (d, m, y) => `${y}-${m}-${d}`;

  const AMT = '-?\\$?[\\d,]+\\.\\d{2,4}';

  /**
   * parsePayslipText(text) ->
   *   { periodStart, periodEnd, gross, net, lines[{desc,units,rate,amount}], leave{AL,SL,LSL}, warnings[] }
   */
  function parsePayslipText(text) {
    const lines = String(text || '').split(/\r?\n/).map((l) => l.replace(/ /g, ' ').trim()).filter(Boolean);
    const out = { periodStart: null, periodEnd: null, gross: null, net: null, lines: [], leave: {}, warnings: [] };

    const periodRe = /(\d{2})\/(\d{2})\/(\d{4})\s*(?:to|-|–)\s*(\d{2})\/(\d{2})\/(\d{4})/i;
    const lineRe = new RegExp(`^(.+?)\\s+(${AMT})\\s+(?:@\\s*)?(${AMT})\\s+(${AMT})$`);
    const grossRe = new RegExp(`\\bgross\\b[^\\d-]*(${AMT})\\s*$`, 'i');
    const netRe = new RegExp(`\\bnet( pay)?\\b[^\\d-]*(${AMT})\\s*$`, 'i');
    const leaveRe = /^(annual leave|AL|personal leave|sick leave|SL|long service leave|LSL)\b.*?(-?\d+\.\d{2})\s*(?:h|hrs|hours)?\s*$/i;

    for (const l of lines) {
      const p = periodRe.exec(l);
      if (p && !out.periodStart) {
        out.periodStart = isoOf(p[1], p[2], p[3]);
        out.periodEnd = isoOf(p[4], p[5], p[6]);
        continue;
      }
      const g = grossRe.exec(l);
      if (g && out.gross == null) { out.gross = num(g[1]); continue; }
      const n = netRe.exec(l);
      if (n && out.net == null) { out.net = num(n[2]); continue; }
      const lv = leaveRe.exec(l);
      if (lv) {
        const k = /^a/i.test(lv[1]) ? 'AL' : /^(p|s)/i.test(lv[1]) ? 'SL' : 'LSL';
        out.leave[k] = num(lv[2]);
        continue;
      }
      const m = lineRe.exec(l);
      if (m) out.lines.push({ desc: m[1].trim(), units: num(m[2]), rate: num(m[3]), amount: num(m[4]) });
    }

    if (!out.periodStart) out.warnings.push('Could not read the pay period dates.');
    if (out.gross == null) out.warnings.push('Could not find a gross pay figure.');
    if (!out.lines.length) out.warnings.push('Could not read any earnings lines (units x rate = amount).');
    return out;
  }

  const ENGINE_COVERED = [
    { key: 'ordinary', re: /ordinary|normal|base|hours worked|saturday|sunday|weekend|public holiday|ph\b/i, label: 'Ordinary hours / penalties' },
    { key: 'shiftAllowance', re: /afternoon|night|shift (allow|penal)|morning/i, label: 'Shift allowance' },
    { key: 'laundry', re: /laundry/i, label: 'Laundry' },
    { key: 'overtime', re: /overtime|\bOT\b/i, label: 'Overtime' },
  ];

  /**
   * crossCheck(payslip, shifts, shiftTypes, provider) -> {
   *   status: 'matches'|'differs'|'unavailable', estimate, gross, difference,
   *   periodShifts, notEstimated[], discrepancies[] }
   * `provider` comes from PayRegistry.providerFor; it must be available.
   */
  function crossCheck(payslip, shifts, shiftTypes, provider) {
    if (!provider || !provider.available) {
      return { status: 'unavailable', reason: (provider && provider.reason) || 'Pay estimate not available.', discrepancies: [], notEstimated: [] };
    }
    if (!payslip.periodStart || !payslip.periodEnd || payslip.gross == null) {
      return { status: 'unavailable', reason: 'The payslip needs a readable pay period and gross figure.', discrepancies: [], notEstimated: [] };
    }
    const inPeriod = shifts.filter((s) => s.date >= payslip.periodStart && s.date <= payslip.periodEnd);
    const sum = provider.engine.summarise(inPeriod, shiftTypes);
    const estimate = round2(sum.estimatedGross);
    const difference = round2(payslip.gross - estimate);
    const discrepancies = [];
    const notEstimated = [];

    if (!inPeriod.length) {
      discrepancies.push('No shifts on this device fall inside the payslip period. Sync your roster first (past shifts may have dropped off EO).');
    }

    // Lines on the payslip the roster-based estimate cannot see (allowances, higher duties, leave, adjustments).
    for (const ln of payslip.lines) {
      const covered = ENGINE_COVERED.find((c) => c.re.test(ln.desc));
      if (!covered) notEstimated.push({ ...ln, why: 'Not something the roster shows (allowance, adjustment, leave or higher duties).' });
    }
    const notEstimatedTotal = round2(notEstimated.reduce((a, l) => a + l.amount, 0));

    // Base rate check: any ordinary-hours line whose rate differs from the rate we used.
    const baseRate = inPeriod.length ? provider.rules.baseHourlyRateOn(inPeriod[0].date) : null;
    if (baseRate) {
      const ord = payslip.lines.find((l) => /ordinary|normal|base/i.test(l.desc) && l.rate > 0);
      if (ord && Math.abs(ord.rate - baseRate.rate) > 0.0051) {
        discrepancies.push(`Payslip base rate $${ord.rate.toFixed(4)} differs from the rate used here ($${baseRate.rate.toFixed(4)}). Check your classification or enter your rate in Settings.`);
      }
    }

    const adjusted = round2(difference - notEstimatedTotal);
    if (Math.abs(adjusted) > 1) {
      discrepancies.push(`After lines the roster cannot see, the payslip is $${Math.abs(adjusted).toFixed(2)} ${adjusted > 0 ? 'above' : 'below'} the estimate.`);
    }
    return {
      status: !discrepancies.length ? 'matches' : 'differs',
      estimate, gross: payslip.gross, difference, adjustedDifference: adjusted,
      periodShifts: inPeriod.length, notEstimated, notEstimatedTotal, discrepancies,
    };
  }

  /** Numbers only: what we keep after the user confirms. */
  function toSummary(payslip, check) {
    return {
      periodStart: payslip.periodStart, periodEnd: payslip.periodEnd, gross: payslip.gross,
      leave: payslip.leave, lines: payslip.lines,
      checkedAt: new Date().toISOString().slice(0, 10),
      status: check && check.status, difference: check && check.difference,
    };
  }

  const api = { parsePayslipText, crossCheck, toSummary };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.Payslip = api;
})(typeof window !== 'undefined' ? window : globalThis);
