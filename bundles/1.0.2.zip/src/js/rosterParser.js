/**
 * rosterParser.js — Employee Online (EO) roster text -> shifts, entirely client-side.
 *
 * Ported from my-roster's tools/import_rosteron.js (Node) to plain JS that runs in the
 * browser, the Android WebView app, and Node (for tests). No DOM, no network, no storage.
 *
 * EO's mobile roster list renders each shift as plain text lines:
 *    Wed 26/08/2026 - <unit>
 *    07:00 - 15:30
 *    <shift code or descriptive label>
 *    <position / role line (ignored)>
 *
 * GUARDRAILS (design carried over from the Hermes tools)
 *   Anything that looks like a layout change or partial data is reported as a HARD
 *   problem and nothing may be saved. Softer oddities (big removals, inferred hours,
 *   a window that does not start near today) need an explicit user confirmation.
 *   "No shifts" is never treated as "an empty roster". See evaluateGuards().
 *
 * STATUS codes mirror the old tools' exit codes, so logs and docs line up.
 */
(function (global) {
  'use strict';

  const STATUS = { ok: 0, error: 1, login: 2, credentials: 3, mfa: 4, expired: 5, layout: 6, guard: 7 };

  const HEADER_RE = /^([A-Z][a-z]{2})\s+(\d{2})\/(\d{2})\/(\d{4})\s*-\s*(.+)$/;
  const TIME_RE = /^(\d{2}):(\d{2})\s*-\s*(\d{2}):(\d{2})$/;
  const DATE_ANYWHERE_RE = /\b\d{2}\/\d{2}\/\d{4}\b/;
  const DOW_SHORT = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
  const DOW_LONG = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

  /** Same limits the Hermes sync used before it asked a human. */
  const LIMITS = { removals: 4, changes: 6, leadDaysMin: -1, leadDaysMax: 21 };

  /* ------------------------------------------------------------------ *
   * Role configuration
   *
   * Nurse: Nurses & Midwives (Vic Public Sector) EA 2024-2028, cl 44.1(a) — a 30 minute
   *        unpaid meal break is deducted when paid hours are inferred from times.
   * Doctor: the medical officers' EA is NOT encoded. No break is deducted and the figure
   *        is labelled "rostered hours", never "paid hours". Nothing here is pay-related.
   * ------------------------------------------------------------------ */

  const NURSE_SHIFT_TYPES = {
    day: { label: 'Day Shift', start: '07:00', end: '15:30', paidHours: 8 },
    afternoon: { label: 'Afternoon Shift', start: '13:00', end: '21:30', paidHours: 8 },
    night: { label: 'Night Shift', start: '21:00', end: '07:30', paidHours: 10 },
  };

  const DOCTOR_SHIFT_TYPES = {
    day: { label: 'Day', start: '08:00', end: '16:30', paidHours: 8.5 },
    afternoon: { label: 'Afternoon / Evening', start: '13:00', end: '21:30', paidHours: 8.5 },
    night: { label: 'Night', start: '21:00', end: '07:30', paidHours: 10.5 },
  };

  const ROLES = {
    nurse: {
      key: 'nurse',
      label: 'Nurse',
      mealBreakHours: 0.5, // EA cl 44.1(a)
      hoursLabel: 'paid hours',
      shiftTypes: NURSE_SHIFT_TYPES,
      // Only the nurse templates are payroll-verified; for doctors they only drive
      // colour-coding and the "add shift" defaults, and never match-by-times.
      matchTemplatesExactly: true,
    },
    doctor: {
      key: 'doctor',
      label: 'Doctor',
      mealBreakHours: 0,
      hoursLabel: 'rostered hours',
      shiftTypes: DOCTOR_SHIFT_TYPES,
      matchTemplatesExactly: false,
    },
  };

  function roleConfig(role) {
    return ROLES[role] || ROLES.nurse;
  }

  /* ------------------------------------------------------------------ *
   * Small helpers
   * ------------------------------------------------------------------ */

  const round2 = (n) => Math.round((n + Number.EPSILON) * 100) / 100;

  function elapsedHours(start, end) {
    const [sh, sm] = start.split(':').map(Number);
    const [eh, em] = end.split(':').map(Number);
    let mins = eh * 60 + em - (sh * 60 + sm);
    if (mins <= 0) mins += 24 * 60; // runs past midnight
    return mins / 60;
  }

  /** Real calendar date check, plus the weekday abbreviation EO printed. */
  function checkDate(dow, iso) {
    const [y, m, d] = iso.split('-').map(Number);
    const dt = new Date(Date.UTC(y, m - 1, d));
    if (dt.getUTCFullYear() !== y || dt.getUTCMonth() !== m - 1 || dt.getUTCDate() !== d) {
      return { ok: false, why: `invalid date ${iso}` };
    }
    if (DOW_SHORT[dt.getUTCDay()] !== dow) return { ok: false, why: `weekday mismatch on ${iso}` };
    return { ok: true, longDay: DOW_LONG[dt.getUTCDay()] };
  }

  function validTime(h, m) {
    return Number(h) <= 23 && Number(m) <= 59;
  }

  /* ------------------------------------------------------------------ *
   * Classification
   * ------------------------------------------------------------------ */

  /**
   * Exact match against a configured template wins (nurses only); otherwise infer the
   * type from the times and, for nurses, deduct the cl 44.1(a) unpaid meal break.
   * Types are inferred from times, never from the label EO prints.
   */
  function classify(shift, roleKey, shiftTypes) {
    const cfg = roleConfig(roleKey);
    const types = shiftTypes || cfg.shiftTypes;
    if (cfg.matchTemplatesExactly) {
      for (const [key, def] of Object.entries(types)) {
        if (def.start === shift.start && def.end === shift.end) {
          return { shiftType: key, paidHours: def.paidHours, exact: true };
        }
      }
    }
    const elapsed = elapsedHours(shift.start, shift.end);
    const sh = Number(shift.start.slice(0, 2));
    const eh = Number(shift.end.slice(0, 2));
    const crossesMidnight = eh * 60 + Number(shift.end.slice(3)) <= sh * 60 + Number(shift.start.slice(3));
    const shiftType = crossesMidnight || sh >= 21 || sh < 5 ? 'night' : eh >= 18 ? 'afternoon' : 'day';
    return { shiftType, paidHours: round2(elapsed - cfg.mealBreakHours), exact: false };
  }

  /* ------------------------------------------------------------------ *
   * Parse
   * ------------------------------------------------------------------ */

  /**
   * parseRosterText(text, { role }) ->
   *   { status, shifts[], problems[], warnings[], duplicates[], stats }
   *
   * `problems` are HARD (layout drift / partial data): status = STATUS.layout and the
   * caller must not save. `warnings` are informational. `shifts` holds one entry per
   * date (the app keys on date); a second shift on the same date is reported in
   * `duplicates` and NOT silently dropped from the report.
   */
  function parseRosterText(text, options) {
    const opts = options || {};
    const lines = String(text == null ? '' : text)
      .split(/\r?\n/)
      .map((l) => l.replace(/ /g, ' ').trim())
      .filter(Boolean);

    const problems = [];
    const warnings = [];
    const raw = [];

    for (let i = 0; i < lines.length; i++) {
      const h = HEADER_RE.exec(lines[i]);
      if (!h) continue;
      const [, dow, dd, mm, yyyy, unit] = h;
      const iso = `${yyyy}-${mm}-${dd}`;

      const dcheck = checkDate(dow, iso);
      if (!dcheck.ok) {
        problems.push(dcheck.why);
        continue;
      }

      let t = null;
      let tIdx = -1;
      for (let j = i + 1; j < Math.min(i + 4, lines.length); j++) {
        if (HEADER_RE.test(lines[j])) break; // never reach into the next shift
        const m = TIME_RE.exec(lines[j]);
        if (m) { t = m; tIdx = j; break; }
      }
      if (!t) {
        problems.push(`no start-end time under ${dow} ${iso}`);
        continue;
      }
      if (!validTime(t[1], t[2]) || !validTime(t[3], t[4])) {
        problems.push(`impossible time ${t[0]} on ${iso}`);
        continue;
      }

      let label = lines[tIdx + 1] || '';
      if (HEADER_RE.test(label) || TIME_RE.test(label)) label = ''; // missing label, not the next row
      raw.push({
        date: iso,
        day: dcheck.longDay,
        start: `${t[1]}:${t[2]}`,
        end: `${t[3]}:${t[4]}`,
        unit: unit.trim(),
        label: label.trim(),
      });
    }

    // Any dated line that did not parse as a header is a layout-drift signal.
    const headerLike = lines.filter((l) => DATE_ANYWHERE_RE.test(l) && !HEADER_RE.test(l));
    if (headerLike.length) {
      problems.push(`${headerLike.length} dated line(s) not in the expected "Ddd dd/mm/yyyy - Unit" form`);
    }

    // One shift per date.
    const byDate = new Map();
    const duplicates = [];
    for (const s of raw) {
      if (byDate.has(s.date)) duplicates.push(s);
      else byDate.set(s.date, s);
    }
    if (duplicates.length) {
      warnings.push(
        `${duplicates.length} extra shift(s) on a date that already has one (${duplicates.map((d) => d.date).join(', ')}). ` +
        'This version keeps one shift per day, so the later entry is not shown.'
      );
    }

    const role = opts.role || 'nurse';
    const shifts = [...byDate.values()]
      .sort((a, b) => a.date.localeCompare(b.date))
      .map((s) => {
        const c = classify(s, role, opts.shiftTypes);
        const out = {
          date: s.date,
          day: s.day,
          shiftType: c.shiftType,
          start: s.start,
          end: s.end,
          paidHours: c.paidHours,
          unit: s.unit,
        };
        // Keep a descriptive label ("Buddy Shift"); drop raw shift codes such as 0700-1530.
        if (s.label && !/^\d{4}-\d{4}/.test(s.label)) out.note = s.label;
        if (!c.exact) out._review = `Times ${s.start}-${s.end} match no known shift pattern; hours inferred.`;
        return out;
      });

    let status = STATUS.ok;
    if (problems.length) status = STATUS.layout;
    else if (!shifts.length) {
      status = STATUS.layout;
      problems.push('no shifts found — refusing to treat that as an empty roster');
    }

    return {
      status,
      shifts,
      problems,
      warnings,
      duplicates,
      stats: {
        rows: raw.length,
        shifts: shifts.length,
        first: shifts.length ? shifts[0].date : null,
        last: shifts.length ? shifts[shifts.length - 1].date : null,
        hours: round2(shifts.reduce((a, s) => a + s.paidHours, 0)),
      },
    };
  }

  /* ------------------------------------------------------------------ *
   * Merge + diff
   * ------------------------------------------------------------------ */

  /**
   * EO lists shifts from (about) today forward, so earlier shifts already on the device
   * are kept: re-syncing never wipes history. A shift with `pinned: true` is never
   * removed, reclassified or relabelled by a sync (a record EO does not list).
   */
  function mergeRoster(existing, imported) {
    const old = (existing || []).map((s) => ({ ...s }));
    const incoming = imported.map((s) => ({ ...s }));
    if (!incoming.length) return { merged: old, diff: diffRosters(old, old), retained: old.length, heldBack: [] };

    const earliest = incoming.reduce((a, s) => (s.date < a ? s.date : a), incoming[0].date);
    const pinned = old.filter((s) => s.pinned === true);
    const pinnedDates = new Set(pinned.map((s) => s.date));
    const retained = old.filter((s) => s.pinned !== true && s.date < earliest);
    const kept = incoming.filter((s) => !pinnedDates.has(s.date));
    const heldBack = incoming.filter((s) => pinnedDates.has(s.date));
    const merged = [...retained, ...pinned, ...kept].sort((a, b) => a.date.localeCompare(b.date));
    return { merged, diff: diffRosters(old, merged), retained: retained.length, heldBack };
  }

  function sameShape(a, b) {
    return a.shiftType === b.shiftType && a.start === b.start && a.end === b.end && a.paidHours === b.paidHours;
  }

  function diffRosters(before, after) {
    const b = new Map(before.map((s) => [s.date, s]));
    const a = new Map(after.map((s) => [s.date, s]));
    const dates = [...new Set([...b.keys(), ...a.keys()])].sort();
    const diff = { added: [], changed: [], removed: [], relabelled: [] };
    for (const d of dates) {
      const x = b.get(d);
      const y = a.get(d);
      if (!x && y) diff.added.push(y);
      else if (x && !y) diff.removed.push(x);
      else if (!sameShape(x, y)) diff.changed.push({ before: x, after: y });
      else if ((x.note || '') !== (y.note || '')) diff.relabelled.push({ before: x, after: y });
    }
    return diff;
  }

  /* ------------------------------------------------------------------ *
   * Guards
   * ------------------------------------------------------------------ */

  function daysBetween(isoA, isoB) {
    const [ya, ma, da] = isoA.split('-').map(Number);
    const [yb, mb, db] = isoB.split('-').map(Number);
    return Math.round((Date.UTC(yb, mb - 1, db) - Date.UTC(ya, ma - 1, da)) / 86400000);
  }

  /**
   * evaluateGuards({ parse, existing, merge, todayIso }) -> { hard[], soft[], notes[] }
   *   hard: do not save, ever (layout drift, truncated list)
   *   soft: save only after the user confirms
   * The first sync (no existing roster) skips the comparison guards.
   */
  function evaluateGuards(ctx) {
    const { parse, existing, merge, todayIso } = ctx;
    const hard = [];
    const soft = [];
    const notes = [];

    hard.push(...parse.problems);
    if (hard.length) return { hard, soft, notes };

    const last = parse.stats.last;
    const lateRemovals = merge.diff.removed.filter((s) => s.date > last);
    if (lateRemovals.length) {
      hard.push(
        `${lateRemovals.length} shift(s) after the last date in this download would be removed ` +
        `(${lateRemovals.map((s) => s.date).join(', ')}) — the list looks truncated.`
      );
    }

    if (todayIso) {
      const lead = daysBetween(todayIso, parse.stats.first);
      if (lead < LIMITS.leadDaysMin || lead > LIMITS.leadDaysMax) {
        soft.push(`The roster window starts ${lead} days from today; expected "today forward".`);
      }
    }

    const hadRoster = (existing || []).length > 0;
    if (hadRoster) {
      if (merge.diff.removed.length > LIMITS.removals) soft.push(`${merge.diff.removed.length} shifts would be removed (limit ${LIMITS.removals}).`);
      if (merge.diff.changed.length > LIMITS.changes) soft.push(`${merge.diff.changed.length} shifts would change (limit ${LIMITS.changes}).`);
      const oldLast = existing.reduce((m, s) => (s.date > m ? s.date : m), '');
      const newLast = merge.merged.reduce((m, s) => (s.date > m ? s.date : m), '');
      if (newLast < oldLast) soft.push(`The last rostered date moves earlier (${oldLast} to ${newLast}).`);
    }

    const review = parse.shifts.filter((s) => s._review);
    if (review.length) {
      soft.push(`${review.length} shift(s) have times that match no known pattern, so hours were inferred: ${review.map((s) => `${s.date} ${s.start}-${s.end}`).join(', ')}.`);
    }
    if (parse.duplicates.length) soft.push(parse.warnings.find((w) => /extra shift/.test(w)));
    return { hard, soft, notes };
  }

  /* ------------------------------------------------------------------ *
   * One-call pipeline used by the app
   * ------------------------------------------------------------------ */

  /**
   * prepareImport(text, { role, existing, todayIso }) -> {
   *   status, parse, merge, guards, canSave, needsConfirm }
   * Pure: never writes anything. The caller persists `merge.merged` when allowed.
   */
  function prepareImport(text, options) {
    const opts = options || {};
    const parse = parseRosterText(text, { role: opts.role });
    const existing = opts.existing || [];
    const merge = parse.shifts.length ? mergeRoster(existing, parse.shifts) : { merged: existing, diff: diffRosters(existing, existing), retained: existing.length, heldBack: [] };
    const guards = evaluateGuards({ parse, existing, merge, todayIso: opts.todayIso });
    const canSave = guards.hard.length === 0;
    const merged = merge.merged.map((s) => {
      const c = { ...s };
      delete c._review;
      return c;
    });
    return {
      status: guards.hard.length ? (parse.status || STATUS.layout) : guards.soft.length ? STATUS.guard : STATUS.ok,
      parse,
      merge: { ...merge, merged },
      guards,
      canSave,
      needsConfirm: canSave && guards.soft.length > 0,
    };
  }

  const api = {
    STATUS,
    LIMITS,
    ROLES,
    roleConfig,
    HEADER_RE,
    TIME_RE,
    elapsedHours,
    classify,
    parseRosterText,
    mergeRoster,
    diffRosters,
    evaluateGuards,
    prepareImport,
  };

  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  global.RosterParser = api;
})(typeof window !== 'undefined' ? window : globalThis);
